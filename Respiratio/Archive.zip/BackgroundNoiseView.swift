import SwiftUI

/// List of background noises that PUSH to a full‑screen player.
struct BackgroundNoiseView: View {
    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(NoiseCatalog.all) { noise in
                        NavigationLink {
                            NoiseSessionView(noise: noise)   // ✅ Pushes as a new page
                        } label: {
                            NoiseRowCard(noise: noise)
                        }
                        .listRowSeparator(.hidden)
                        .listRowBackground(Color.clear)
                    }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .padding(.top, 4)
            .navigationTitle("Background Noise")
            .background(Color(.systemGroupedBackground))
        }
    }
}

// MARK: - Row Card

private struct NoiseRowCard: View {
    let noise: BackgroundNoise

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                Circle().fill(Color.blue.opacity(0.14))
                Image(systemName: "waveform")
                    .foregroundStyle(.blue)
                    .font(.system(size: 18, weight: .semibold))
            }
            .frame(width: 40, height: 40)

            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(noise.title)
                        .font(.headline)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.subheadline)
                        .foregroundStyle(.tertiary)
                }

                Text(noise.summary)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 8) {
                    ForEach(noise.tags, id: \.self) { tag in
                        Text(tag.capitalized)
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(
                                Capsule().fill(Color.blue.opacity(0.12))
                            )
                    }
                }
                .padding(.top, 2)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.thinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(Color.black.opacity(0.06), lineWidth: 0.5)
                )
        )
    }
}
