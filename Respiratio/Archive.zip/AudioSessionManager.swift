//
//  AudioSessionManager.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-22.
//

import AVFoundation

enum AudioSessionManager {
    static func activate() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetooth])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
        } catch { print("AudioSession error:", error) }
    }

    static func deactivate() {
        do { try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) }
        catch { print("AudioSession deactivate error:", error) }
    }
}
