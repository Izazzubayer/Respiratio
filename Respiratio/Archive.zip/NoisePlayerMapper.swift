import Foundation

/// A simple, reflection‑based descriptor so you can keep your existing BackgroundNoise model
/// without changing its property names. We’ll try to infer title/tags/file from common keys.
struct NoiseDescriptor {
    let title: String
    let tags: [String]
    let fileName: String   // bundle resource name WITHOUT extension
    let fileExt: String    // resource extension (default "mp3")
}

/// Build a descriptor from ANY model (e.g. your BackgroundNoise) by scanning common property names.
/// Works whether you named them `title`/`name`, `tags`/`keywords`, `fileName`/`sound`/`audio`, etc.
func makeNoiseDescriptor(from noise: Any) -> NoiseDescriptor {
    // 1) Try to read fields via Mirror
    let mirror = Mirror(reflecting: noise)

    // Title
    let title = extractString(in: mirror, keys: [
        "title","name","displayName","label"
    ]) ?? "Background Noise"

    // Tags
    let tags: [String] = extractStringArray(in: mirror, keys: ["tags","keywords","labels","categories"])
        ?? (extractString(in: mirror, keys: ["tags","keywords","labels","categories"])?.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) } ?? [])

    // Source (String or URL). Accept many names.
    let candidates = ["fileName","filename","file","resource","resourceName","audio","sound","asset","path","url","audioURL","soundURL"]

    // Prefer URL‑like first
    if let urlString = extractString(in: mirror, keys: candidates), let url = URL(string: urlString) {
        let (base, ext) = splitName(url.lastPathComponent)
        return NoiseDescriptor(title: title, tags: tags, fileName: base, fileExt: ext ?? "mp3")
    }
    if let url = extractURL(in: mirror, keys: candidates) {
        let (base, ext) = splitName(url.lastPathComponent)
        return NoiseDescriptor(title: title, tags: tags, fileName: base, fileExt: ext ?? "mp3")
    }
    // Then plain string field (may include extension)
    if let name = extractString(in: mirror, keys: candidates) {
        let (base, ext) = splitName(name)
        return NoiseDescriptor(title: title, tags: tags, fileName: base, fileExt: ext ?? "mp3")
    }

    // Fallback
    return NoiseDescriptor(title: title, tags: tags, fileName: "white_noise", fileExt: "mp3")
}

// MARK: - Helpers

private func extractString(in mirror: Mirror, keys: [String]) -> String? {
    for child in mirror.children {
        guard let label = child.label?.lowercased() else { continue }
        if keys.contains(label) {
            if let v = child.value as? String { return v }
            if let url = child.value as? URL { return url.absoluteString }
        }
    }
    return nil
}

private func extractStringArray(in mirror: Mirror, keys: [String]) -> [String]? {
    for child in mirror.children {
        guard let label = child.label?.lowercased() else { continue }
        if keys.contains(label) {
            if let arr = child.value as? [String] { return arr }
        }
    }
    return nil
}

private func extractURL(in mirror: Mirror, keys: [String]) -> URL? {
    for child in mirror.children {
        guard let label = child.label?.lowercased() else { continue }
        if keys.contains(label) {
            if let url = child.value as? URL { return url }
        }
    }
    return nil
}

private func splitName(_ name: String) -> (base: String, ext: String?) {
    let ns = name as NSString
    let base = ns.deletingPathExtension.isEmpty ? name : ns.deletingPathExtension
    let ext = ns.pathExtension.isEmpty ? nil : ns.pathExtension
    return (base, ext)
}
