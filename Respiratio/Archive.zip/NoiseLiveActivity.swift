//
//  Untitled.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-22.
//

import ActivityKit
import SwiftUI
import WidgetKit

struct NoiseActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var title: String
        var remainingSeconds: Int?
        var isPlaying: Bool
    }
}

@main
struct NoiseWidgetBundle: WidgetBundle {
    var body: some Widget {
        NoiseLiveActivityWidget()
    }
}

struct NoiseLiveActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: NoiseActivityAttributes.self) { context in
            // Lock Screen / expanded
            VStack(alignment: .leading, spacing: 6) {
                Text(context.state.title).font(.headline)
                if let rem = context.state.remainingSeconds {
                    Text("Time remaining: \(format(rem))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Text("Playing").font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 12)

        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: context.state.isPlaying ? "play.fill" : "pause.fill")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if let rem = context.state.remainingSeconds {
                        Text(format(rem)).monospacedDigit()
                    }
                }
                DynamicIslandExpandedRegion(.center) {
                    Text(context.state.title).font(.subheadline)
                }
            } compactLeading: {
                Image(systemName: context.state.isPlaying ? "play.fill" : "pause.fill")
            } compactTrailing: {
                if let rem = context.state.remainingSeconds {
                    Text(shortFormat(rem)).monospacedDigit()
                } else { Text("∞") }
            } minimal: {
                Image(systemName: "waveform")
            }
        }
    }
}

private func format(_ seconds: Int) -> String {
    let m = seconds / 60, s = seconds % 60
    return String(format: "%d:%02d", m, s)
}
private func shortFormat(_ seconds: Int) -> String {
    let m = seconds / 60
    return "\(m)m"
}
