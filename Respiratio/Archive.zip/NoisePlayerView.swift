import SwiftUI
import AVFoundation
import AVKit           // AVRoutePickerView
import MediaPlayer     // Now Playing / remote controls
import UIKit

// MARK: - Duration

// Make this internal (no 'private') so it can be used by published properties
enum NoiseDuration: Hashable {
    case infinite
    case minutes(Int)

    var label: String {
        switch self {
        case .infinite: return "∞"
        case .minutes(let m): return "\(m)m"
        }
    }

    var totalSeconds: TimeInterval? {
        switch self {
        case .infinite: return nil
        case .minutes(let m): return TimeInterval(m * 60)
        }
    }
}

// MARK: - Player Controller

final class NoisePlayerController: ObservableObject {
    // UI state
    @Published var isPlaying = false
    @Published var selectedDuration: NoiseDuration = .infinite {
        didSet { rearmTimerForSelection() }
    }
    @Published var elapsed: TimeInterval = 0
    @Published var volume: Float = 0.7 {
        didSet { player?.volume = isFading ? fadeWorkingVolume : volume }
    }
    @Published var fadeInEnabled = true
    @Published var fadeOutEnabled = true

    // audio
    private let fileName: String
    private let fileExt: String
    private var player: AVAudioPlayer?
    private var tick: CADisplayLink?

    // fading
    private var isFading = false
    private var fadeStartTime: CFTimeInterval = 0
    private var fadeDuration: CFTimeInterval = 0
    private var fadeFrom: Float = 0
    private var fadeTo: Float = 0
    private var fadeCompletion: (() -> Void)?
    fileprivate var fadeWorkingVolume: Float = 0

    init(fileName: String, fileExt: String = "mp3") {
        self.fileName = fileName
        self.fileExt  = fileExt
        configureSession()
        preparePlayer()
        setupRemoteCommands()
    }

    // MARK: session / player

    private func configureSession() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
        } catch { print("Audio session error:", error) }
    }

    private func preparePlayer() {
        guard let url = Bundle.main.url(forResource: fileName, withExtension: fileExt) else {
            print("⚠️ Could not find resource \(fileName).\(fileExt)")
            return
        }
        do {
            let p = try AVAudioPlayer(contentsOf: url)
            p.numberOfLoops = -1 // loop forever (timer stops if finite)
            p.volume = volume
            p.prepareToPlay()
            player = p
            updateNowPlaying(for: .paused)
        } catch {
            print("AVAudioPlayer error:", error)
        }
    }

    // MARK: transport

    func play() {
        guard let p = player else { return }
        if selectedDuration.totalSeconds == nil { elapsed = 0 }

        if fadeInEnabled {
            // Start silent, then fade to target
            p.volume = 0
            p.play()
            fade(to: volume, duration: 1.0, completion: nil)
        } else {
            p.volume = volume
            p.play()
        }

        isPlaying = true
        startTicker()
        updateNowPlaying(for: .playing)
        UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
    }

    func pause() {
        guard let _ = player else { return }
        let done: () -> Void = { [weak self] in
            self?.player?.pause()
        }
        if fadeOutEnabled {
            fade(to: 0, duration: 0.35, completion: done)
        } else {
            done()
        }
        isPlaying = false
        stopTicker()
        updateNowPlaying(for: .paused)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }


    func stop() {
        let stopAction = { [weak self] in
            self?.player?.stop()
            self?.player?.currentTime = 0
        }
        if fadeOutEnabled { fade(to: 0, duration: 0.35, completion: stopAction) } else { stopAction() }
        isPlaying = false
        stopTicker()
        elapsed = 0
        updateNowPlaying(for: .stopped)
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    func seek(to newElapsed: TimeInterval) {
        guard let limit = selectedDuration.totalSeconds else { return }
        elapsed = max(0, min(limit, newElapsed))
    }

    func nudge(by seconds: TimeInterval) {
        guard let limit = selectedDuration.totalSeconds else { return }
        seek(to: elapsed + seconds)
    }

    // MARK: timer

    private func rearmTimerForSelection() {
        if selectedDuration.totalSeconds != nil { elapsed = 0 }
        if isPlaying { startTicker() }
        updateNowPlaying(for: isPlaying ? .playing : .paused)
    }

    private func startTicker() {
        stopTicker()
        let link = CADisplayLink(target: self, selector: #selector(step))
        link.add(to: .main, forMode: .common)
        tick = link
    }

    private func stopTicker() {
        tick?.invalidate()
        tick = nil
    }

    @objc private func step() {
        // fade progression
        if isFading { advanceFade() }

        // progress time only if finite and playing
        guard isPlaying, let total = selectedDuration.totalSeconds else { return }
        elapsed = min(total, elapsed + (tick?.duration ?? 1/60))
        if elapsed >= total { stop() }
        updateNowPlaying(for: .playing)
    }

    // MARK: fade helper

    private func fade(to target: Float, duration: CFTimeInterval, completion: (() -> Void)? = nil) {
        guard let p = player else { completion?(); return }
        isFading = true
        fadeStartTime = CACurrentMediaTime()
        fadeDuration = max(0.01, duration)
        fadeFrom = p.volume
        fadeTo = target
        fadeWorkingVolume = p.volume
        fadeCompletion = completion
    }

    private func advanceFade() {
        guard let p = player else { isFading = false; return }
        let t = (CACurrentMediaTime() - fadeStartTime) / fadeDuration
        if t >= 1 {
            p.volume = fadeTo
            isFading = false
            fadeCompletion?()
            fadeCompletion = nil
            return
        }
        let v = fadeFrom + Float(t) * (fadeTo - fadeFrom)
        fadeWorkingVolume = v
        p.volume = v
    }

    // MARK: now playing

    private enum PlayState { case playing, paused, stopped }

    private func updateNowPlaying(for state: PlayState) {
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: fileName.replacingOccurrences(of: "_", with: " ").capitalized,
            MPNowPlayingInfoPropertyPlaybackRate: state == .playing ? 1.0 : 0.0
        ]

        if let total = selectedDuration.totalSeconds {
            info[MPMediaItemPropertyPlaybackDuration] = total
            info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
        } else {
            info[MPNowPlayingInfoPropertyIsLiveStream] = true
        }

        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func setupRemoteCommands() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in self?.play(); return .success }
        c.pauseCommand.addTarget { [weak self] _ in self?.pause(); return .success }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in
            guard let self else { return .commandFailed }
            self.isPlaying ? self.pause() : self.play()
            return .success
        }
        c.stopCommand.addTarget { [weak self] _ in self?.stop(); return .success }
        c.changePlaybackPositionCommand.isEnabled = false // timer‑driven
    }
}

// MARK: - Main View

struct NoisePlayerView: View {
    let title: String
    let tags: [String]
    let description: String?
    let fileName: String
    let fileExt: String

    @StateObject private var controller: NoisePlayerController

    private let presets: [NoiseDuration] = [.infinite, .minutes(5), .minutes(10), .minutes(15), .minutes(20), .minutes(30), .minutes(60)]

    init(title: String, tags: [String], description: String? = nil, fileName: String, fileExt: String = "mp3") {
        self.title = title
        self.tags = tags
        self.description = description
        self.fileName = fileName
        self.fileExt = fileExt
        _controller = .init(wrappedValue: NoisePlayerController(fileName: fileName, fileExt: fileExt))
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(.systemBackground), Color(.secondarySystemBackground)],
                           startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text(title)
                        .font(.system(size: 42, weight: .bold))

                    FlowChips(tags: tags)

                    if let d = description, !d.isEmpty {
                        Text(d)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }

                    PlayerCard
                    TransportBar
                    DurationPicker
                    VolumeRow
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 24)
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                RoutePicker().frame(width: 28, height: 28)
            }
        }
        .onDisappear { controller.pause() }
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: sections

    private var PlayerCard: some View {
        VStack(spacing: 18) {
            ZStack {
                Circle()
                    .fill(.ultraThinMaterial)
                    .frame(width: 220, height: 220)
                    .overlay(Circle().stroke(Color.gray.opacity(0.2), lineWidth: 14))
                    .shadow(color: .black.opacity(0.08), radius: 20, y: 8)

                Button(action: toggle) {
                    Image(systemName: controller.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 88, height: 88)
                        .background(Circle().fill(Color.accentColor))
                        .shadow(color: Color.accentColor.opacity(0.35), radius: 12, y: 6)
                }

                VStack {
                    Spacer()
                    Text(remainingText)
                        .font(.headline.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
                .frame(height: 220)
            }
            .frame(maxWidth: .infinity)

            VStack(spacing: 6) {
                HStack {
                    Text(elapsedText)
                    Spacer()
                    Text(totalText)
                }
                .font(.caption.monospacedDigit())
                .foregroundStyle(.secondary)

                Slider(value: Binding(get: {
                    guard let total = controller.selectedDuration.totalSeconds else { return 0 }
                    return controller.elapsed / total
                }, set: { newValue in
                    guard let total = controller.selectedDuration.totalSeconds else { return }
                    controller.seek(to: total * newValue)
                }), in: 0...1)
                .disabled(controller.selectedDuration.totalSeconds == nil)
            }
            .padding(.horizontal, 6)
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(.thinMaterial))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(Color.black.opacity(0.06), lineWidth: 0.5)
        )
    }

    private var TransportBar: some View {
        HStack(spacing: 28) {
            Button {
                controller.nudge(by: -15)
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            } label: {
                Image(systemName: "gobackward.15").font(.title2)
            }
            .disabled(controller.selectedDuration.totalSeconds == nil)

            Button(action: toggle) {
                Image(systemName: controller.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 56))
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(Color.accentColor) // ✅ ShapeStyle uses Color here
            }

            Button {
                controller.nudge(by: 15)
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            } label: {
                Image(systemName: "goforward.15").font(.title2)
            }
            .disabled(controller.selectedDuration.totalSeconds == nil)

            Spacer()

            HStack(spacing: 16) {
                ToggleIcon(isOn: $controller.fadeInEnabled,
                           systemImage: "arrowtriangle.right.fill", label: "Fade‑in")
                ToggleIcon(isOn: $controller.fadeOutEnabled,
                           systemImage: "arrowtriangle.backward.fill", label: "Fade‑out")
            }
        }
        .padding(.horizontal, 6)
    }

    private var DurationPicker: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Duration").font(.headline)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(presets, id: \.self) { option in
                        let selected = option == controller.selectedDuration
                        Button {
                            controller.selectedDuration = option
                        } label: {
                            Text(option.label)
                                .font(.subheadline.weight(.semibold))
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                                .background(Capsule().fill(selected ? Color.accentColor.opacity(0.20) : Color(.tertiarySystemFill)))
                                .foregroundColor(selected ? Color.accentColor : Color.primary)
                        }
                    }

                    Button {
                        showCustomMinutesPrompt()
                    } label: {
                        Label("Custom", systemImage: "timer")
                            .font(.subheadline.weight(.semibold))
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Capsule().fill(Color(.tertiarySystemFill)))
                    }
                }
            }
        }
    }

    private var VolumeRow: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Volume").font(.headline)
                Spacer()
                RoutePicker()
            }
            HStack {
                Image(systemName: "speaker.fill")
                Slider(value: Binding(get: { Double(controller.volume) },
                                      set: { controller.volume = Float($0) }), in: 0...1)
                Image(systemName: "speaker.wave.3.fill")
            }
            HStack(spacing: 12) {
                Button {
                    controller.pause()
                } label: {
                    Label("Pause", systemImage: "pause.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)

                Button(role: .destructive) {
                    controller.stop()
                } label: {
                    Label("Stop", systemImage: "stop.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
            }
            .padding(.top, 6)
        }
    }

    // MARK: helpers

    private func toggle() {
        controller.isPlaying ? controller.pause() : controller.play()
    }

    private var elapsedText: String {
        let e = Int(controller.elapsed)
        return String(format: "%02d:%02d", e/60, e%60)
    }

    private var totalText: String {
        guard let total = controller.selectedDuration.totalSeconds else { return "∞" }
        let t = Int(total)
        return String(format: "%02d:%02d", t/60, t%60)
    }

    private var remainingText: String {
        guard let total = controller.selectedDuration.totalSeconds else { return "∞" }
        let rem = max(0, Int(total - controller.elapsed))
        return String(format: "%d:%02d", rem/60, rem%60)
    }

    private func showCustomMinutesPrompt() {
        let alert = UIAlertController(title: "Custom Duration",
                                      message: "Enter minutes (1–180)",
                                      preferredStyle: .alert)
        alert.addTextField { tf in
            tf.placeholder = "e.g. 45"
            tf.keyboardType = .numberPad
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Set", style: .default, handler: { _ in
            if let text = alert.textFields?.first?.text,
               let m = Int(text), (1...180).contains(m) {
                controller.selectedDuration = .minutes(m)
            }
        }))
        UIApplication.shared.topMostController?.present(alert, animated: true)
    }
}

// MARK: - Small components

private struct ToggleIcon: View {
    @Binding var isOn: Bool
    let systemImage: String
    let label: String

    var body: some View {
        Button {
            isOn.toggle()
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        } label: {
            VStack(spacing: 4) {
                Image(systemName: systemImage)
                    .font(.headline)
                    .foregroundStyle(isOn ? Color.accentColor : Color.secondary)
                Text(label)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding(8)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color(.tertiarySystemFill)))
        }
    }
}

// Chips
private struct FlowChips: View {
    let tags: [String]
    var body: some View {
        FlexibleChips(data: tags, spacing: 8, alignment: .leading) { tag in
            Text(tag)
                .font(.subheadline.weight(.semibold))
                .padding(.vertical, 6)
                .padding(.horizontal, 10)
                .background(Capsule().fill(Color.blue.opacity(0.15)))
        }
    }
}

private struct FlexibleChips<Data: Collection, Content: View>: View where Data.Element: Hashable {
    let data: Data
    let spacing: CGFloat
    let alignment: HorizontalAlignment
    let content: (Data.Element) -> Content

    init(data: Data, spacing: CGFloat, alignment: HorizontalAlignment, @ViewBuilder content: @escaping (Data.Element) -> Content) {
        self.data = data
        self.spacing = spacing
        self.alignment = alignment
        self.content = content
    }

    var body: some View {
        GeometryReader { proxy in
            let maxWidth = proxy.size.width
            let rows = buildRows(maxWidth: maxWidth)
            VStack(alignment: alignment, spacing: spacing) {
                ForEach(rows.indices, id: \.self) { i in
                    HStack(spacing: spacing) {
                        ForEach(rows[i], id: \.self) { item in content(item) }
                    }
                }
            }
        }
        .frame(minHeight: 0)
        .fixedSize(horizontal: false, vertical: true)
    }

    private func buildRows(maxWidth: CGFloat) -> [[Data.Element]] {
        var rows: [[Data.Element]] = [[]]
        var rowWidth: CGFloat = 0
        let pad: CGFloat = 24

        for item in data {
            let text = String(describing: item)
            let w = text.size(withAttributes: [.font: UIFont.preferredFont(forTextStyle: .subheadline)]).width + pad
            if rowWidth + w + spacing > maxWidth {
                rows.append([item]); rowWidth = w
            } else {
                if rows.last?.isEmpty ?? true { rows[rows.count - 1] = [item] }
                else { rows[rows.count - 1].append(item) }
                rowWidth += w + spacing
            }
        }
        return rows
    }
}

// MARK: - AirPlay

private struct RoutePicker: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let v = AVRoutePickerView()
        v.activeTintColor = UIColor.label
        v.tintColor = UIColor.secondaryLabel
        return v
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

// MARK: - UIKit helper

private extension UIApplication {
    var topMostController: UIViewController? {
        guard let root = connectedScenes
            .compactMap({ ($0 as? UIWindowScene)?.keyWindow })
            .first?.rootViewController else { return nil }
        return top(from: root)
    }

    func top(from vc: UIViewController) -> UIViewController {
        if let nav = vc as? UINavigationController { return top(from: nav.visibleViewController ?? nav) }
        if let tab = vc as? UITabBarController { return top(from: tab.selectedViewController ?? tab) }
        if let presented = vc.presentedViewController { return top(from: presented) }
        return vc
    }
}

// MARK: - Convenience init (use this; DELETE the old Convenience file to avoid redeclaration)

extension NoisePlayerView {
    init(noise: BackgroundNoise) {
        self.init(
            title: noise.title,
            tags: noise.tags,
            description: noise.summary,
            fileName: noise.fileName,
            fileExt: noise.fileExt
        )
    }
}
