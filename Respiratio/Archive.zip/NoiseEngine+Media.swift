//
//  NoiseEngine+Media.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-22.
//

import Foundation
import AVFoundation

extension NoiseEngine {

    /// Call once (e.g., in App launch or the first time noise screen opens)
    static func configureRemotesWith(engine: NoiseEngine) {
        NowPlayingManager.shared.configureRemotes(
            onPlay:  { [weak engine] in engine?.play() },
            onPause: { [weak engine] in engine?.pause() },
            onStop:  { [weak engine] in engine?.stop() }
        )
    }

    // MARK: Wire up session + now playing + live activity

    func prepareForPlayback(title: String) {
        AudioSessionManager.activate()
        NowPlayingManager.shared.set(metadata: title)
        Self.configureRemotesWith(engine: self)
    }

    func didStart(title: String) {
        let remaining = selectedDuration.timeInterval.map { max(0, Int($0 - elapsed)) }
        NowPlayingManager.shared.update(elapsed: elapsed, duration: selectedDuration.timeInterval, isPlaying: true)
        NoiseLiveActivityManager.start(title: title, remaining: remaining)
    }

    func didTick(title: String) {
        let remaining = selectedDuration.timeInterval.map { max(0, Int($0 - elapsed)) }
        NowPlayingManager.shared.update(elapsed: elapsed, duration: selectedDuration.timeInterval, isPlaying: isPlaying)
        NoiseLiveActivityManager.update(title: title, remaining: remaining, isPlaying: isPlaying)
    }

    func didPause(title: String) {
        let remaining = selectedDuration.timeInterval.map { max(0, Int($0 - elapsed)) }
        NowPlayingManager.shared.update(elapsed: elapsed, duration: selectedDuration.timeInterval, isPlaying: false)
        NoiseLiveActivityManager.update(title: title, remaining: remaining, isPlaying: false)
    }

    func didStop() {
        NowPlayingManager.shared.clear()
        NoiseLiveActivityManager.end()
        AudioSessionManager.deactivate()
    }
}
