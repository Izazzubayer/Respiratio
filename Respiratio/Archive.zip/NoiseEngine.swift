import Foundation
import AVFoundation
import MediaPlayer

/// Lightweight engine for looping ambient audio + sleep timer.
final class NoiseEngine: ObservableObject {
    // MARK: Published UI state
    @Published var isPlaying: Bool = false
    @Published var elapsed: TimeInterval = 0          // seconds since session start (for timed sessions)
    @Published var selectedDuration: BNDuration = .infinite {
        didSet { resetTimerForSelection() }
    }
    @Published var volume: Float = 0.7 {
        didSet { player?.volume = isMuted ? 0 : volume }
    }
    @Published var isMuted: Bool = false {
        didSet { player?.volume = isMuted ? 0 : volume }
    }

    // MARK: Internal
    private var player: AVAudioPlayer?
    private var tickTimer: Timer?
    private var sessionStart: Date?
    private var sessionEnd: Date?

    private var currentNoise: BackgroundNoise?

    // MARK: Setup
    func load(noise: BackgroundNoise) {
        currentNoise = noise
        configureSession()
        preparePlayer(for: noise)
        updateNowPlaying(isPlaying: false)
    }

    private func configureSession() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
        } catch {
            print("Audio session error:", error)
        }
        setupRemoteCommands()
    }

    private func preparePlayer(for noise: BackgroundNoise) {
        guard let url = Bundle.main.url(forResource: noise.fileName, withExtension: noise.fileExt) else {
            print("⚠️ Missing resource \(noise.fileName).\(noise.fileExt)")
            return
        }
        do {
            let p = try AVAudioPlayer(contentsOf: url)
            p.numberOfLoops = -1               // loop continuously; we stop via timer if needed
            p.volume = isMuted ? 0 : volume
            p.prepareToPlay()
            player = p
        } catch {
            print("AVAudioPlayer error:", error)
        }
    }

    // MARK: Transport
    func play() {
        guard let p = player else { return }
        // establish timing window
        let now = Date()
        sessionStart = now
        if let total = selectedDuration.timeInterval {
            sessionEnd = now.addingTimeInterval(total)
            elapsed = 0
        } else {
            sessionEnd = nil
            elapsed = 0     // display from zero; infinite has no end
        }
        p.play()
        isPlaying = true
        startTicking()
        updateNowPlaying(isPlaying: true)
        UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
    }

    func pause() {
        player?.pause()
        isPlaying = false
        stopTicking()
        updateNowPlaying(isPlaying: false)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    func stop() {
        player?.stop()
        player?.currentTime = 0
        isPlaying = false
        stopTicking()
        elapsed = 0
        sessionStart = nil
        sessionEnd = nil
        updateNowPlaying(isPlaying: false)
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    /// Nudge timer forward/backward for timed sessions.
    func nudge(by seconds: TimeInterval) {
        guard let start = sessionStart, let total = selectedDuration.timeInterval else { return }
        let newElapsed = max(0, min(total, elapsed + seconds))
        elapsed = newElapsed
        sessionStart = Date().addingTimeInterval(-newElapsed)
        sessionEnd = start.addingTimeInterval(total)  // keep original duration
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        updateNowPlaying(isPlaying: isPlaying)
    }

    /// Seek by fraction [0...1] along the duration.
    func seek(fraction: Double) {
        guard let total = selectedDuration.timeInterval else { return }
        let clamped = max(0, min(1, fraction))
        let newElapsed = clamped * total
        elapsed = newElapsed
        sessionStart = Date().addingTimeInterval(-newElapsed)
        updateNowPlaying(isPlaying: isPlaying)
    }

    // MARK: Timer
    private func startTicking() {
        stopTicking()
        tickTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.tick()
        }
        RunLoop.main.add(tickTimer!, forMode: .common)
    }

    private func stopTicking() {
        tickTimer?.invalidate()
        tickTimer = nil
    }

    private func tick() {
        guard isPlaying else { return }
        // update elapsed for timed sessions
        if let start = sessionStart, let _ = selectedDuration.timeInterval {
            elapsed = Date().timeIntervalSince(start)
        }
        // finish if reached end
        if let end = sessionEnd, Date() >= end {
            stop()
        } else {
            updateNowPlaying(isPlaying: true)
        }
    }

    private func resetTimerForSelection() {
        // keep playing if already playing; reset timing window for finite durations
        guard isPlaying else { return }
        let now = Date()
        sessionStart = now
        if let total = selectedDuration.timeInterval {
            sessionEnd = now.addingTimeInterval(total)
            elapsed = 0
        } else {
            sessionEnd = nil
            elapsed = 0
        }
        updateNowPlaying(isPlaying: true)
    }

    // MARK: Now Playing / Remote
    private func updateNowPlaying(isPlaying: Bool) {
        guard let noise = currentNoise else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: noise.title,
            MPMediaItemPropertyArtist: "Respiratio",
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
        if let total = selectedDuration.timeInterval {
            info[MPMediaItemPropertyPlaybackDuration] = total
            info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
        } else {
            info[MPNowPlayingInfoPropertyIsLiveStream] = true
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func setupRemoteCommands() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in self?.play(); return .success }
        c.pauseCommand.addTarget { [weak self] _ in self?.pause(); return .success }
        c.stopCommand.addTarget { [weak self] _ in self?.stop(); return .success }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in
            guard let self else { return .commandFailed }
            self.isPlaying ? self.pause() : self.play()
            return .success
        }
        c.changePlaybackPositionCommand.isEnabled = false   // we map seeking via our UI only
    }
}
