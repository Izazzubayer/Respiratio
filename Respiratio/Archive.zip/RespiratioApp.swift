//
//  RespiratioApp.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-20.
//

import SwiftUI

@main
struct RespiratioApp: App {
    init() {
        // Ensure session is ready even before first play
        AudioSessionManager.activate()
        // Allow Control Center remote commands to target the shared engine
        NowPlayingManager.shared.configureRemotes(
            onPlay:  { NoiseEngine.shared?.play()  },
            onPause: { NoiseEngine.shared?.pause() },
            onStop:  { NoiseEngine.shared?.stop()  }
        )
    }

    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
