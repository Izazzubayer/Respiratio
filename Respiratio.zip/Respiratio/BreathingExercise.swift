//
//  BreathingExercise.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-21.
//

import Foundation

struct BreathingExercise: Identifiable {
    let id = UUID()
    let name: String
    let description: String
    let tag: String
    let pattern: [(label: String, duration: Double)] // seconds per phase
}

let breathingExercises: [BreathingExercise] = [
    BreathingExercise(
        name: "Box Breathing",
        description: "Calms the mind and reduces stress by regulating breath.",
        tag: "Stress Relief",
        pattern: [("Inhale", 4.0), ("Hold", 4.0), ("Exhale", 4.0), ("Hold", 4.0)]
    ),
    BreathingExercise(
        name: "4-7-8 Breathing",
        description: "Helps you relax and fall asleep faster.",
        tag: "Sleep Aid",
        pattern: [("Inhale", 4.0), ("Hold", 7.0), ("Exhale", 8.0)]
    ),
    BreathingExercise(
        name: "Alternate Nostril",
        description: "Balances left and right brain, improves focus.",
        tag: "Focus & Balance",
        pattern: [("Inhale Right", 4.0), ("Hold", 4.0), ("Exhale Left", 4.0), ("Hold", 4.0)]
    ),
    BreathingExercise(
        name: "Pursed Lip Breathing",
        description: "Improves lung efficiency and slows down breathing.",
        tag: "Breathing Control",
        pattern: [("Inhale", 2.0), ("Exhale", 4.0)]
    ),
    BreathingExercise(
        name: "Lion's Breath",
        description: "Relieves tension, energizes body and mind.",
        tag: "Energy & Release",
        pattern: [("Inhale", 4.0), ("Exhale", 4.0)]
    )
]
