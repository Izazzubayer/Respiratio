//
//  RespiratioApp.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-20.
//

import SwiftUI

@main
struct RespiratioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
