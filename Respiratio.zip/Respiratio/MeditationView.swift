//
//  MeditationView.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-20.
//

import SwiftUI

struct MeditationView: View {
    var body: some View {
        NavigationView {
            List {
                // Quick Meditations Section
                Section(header: Label("Quick Meditations", systemImage: "clock")
                    .font(.headline)) {
                    
                    NavigationLink(destination: MeditationSessionView(duration: 2 * 60)) {
                        MeditationCard(title: "2-Minute Meditation", icon: "leaf.fill", time: "2 min", level: "Beginner")
                    }
                    
                    NavigationLink(destination: MeditationSessionView(duration: 5 * 60)) {
                        MeditationCard(title: "5-Minute Meditation", icon: "leaf.fill", time: "5 min", level: "Beginner")
                    }
                    
                    NavigationLink(destination: MeditationSessionView(duration: 10 * 60)) {
                        MeditationCard(title: "10-Minute Meditation", icon: "leaf.fill", time: "10 min", level: "Intermediate")
                    }
                    
                    NavigationLink(destination: MeditationSessionView(duration: 15 * 60)) {
                        MeditationCard(title: "15-Minute Meditation", icon: "leaf.fill", time: "15 min", level: "Intermediate")
                    }
                    
                    NavigationLink(destination: MeditationSessionView(duration: 20 * 60)) {
                        MeditationCard(title: "20-Minute Meditation", icon: "leaf.fill", time: "20 min", level: "Advanced")
                    }
                    
                    NavigationLink(destination: MeditationSessionView(duration: 30 * 60)) {
                        MeditationCard(title: "30-Minute Meditation", icon: "leaf.fill", time: "30 min", level: "Pro")
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Meditation") // Large title
        }
    }
}

// Card Row
struct MeditationCard: View {
    var title: String
    var icon: String
    var time: String
    var level: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(.accentColor)
                .frame(width: 32)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.headline)
                HStack {
                    Text(time)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Spacer()
                    Text(level)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .italic()
                }
            }
        }
        .padding(.vertical, 6)
    }
}
