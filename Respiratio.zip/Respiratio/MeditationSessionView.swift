//
//  MeditationSessionView.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-21.
//

import SwiftUI

struct MeditationSessionView: View {
    let duration: Int // duration in seconds
    
    @State private var timeRemaining: Int
    @State private var isPlaying = true
    @Environment(\.dismiss) private var dismiss
    
    init(duration: Int) {
        self.duration = duration
        _timeRemaining = State(initialValue: duration)
    }
    
    var body: some View {
        VStack(spacing: 40) {
            Spacer()
            
            // Timer display
            Text(formatTime(timeRemaining))
                .font(.system(size: 48, weight: .bold, design: .rounded))
                .padding()
            
            // Control buttons
            HStack(spacing: 30) {
                
                // Play / Pause button
                Button(action: { isPlaying.toggle() }) {
                    Text(isPlaying ? "Pause" : "Play")
                        .frame(width: 120, height: 44)
                }
                .buttonStyle(.borderedProminent)
                .tint(.accentColor) // iOS default accent
                
                // Stop button
                Button(action: { dismiss() }) {
                    Text("Stop")
                        .frame(width: 120, height: 44)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
            }
            
            Spacer()
        }
        .navigationTitle("Meditation")
        .navigationBarTitleDisplayMode(.inline)
        .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { _ in
            if isPlaying && timeRemaining > 0 {
                timeRemaining -= 1
            }
        }
    }
    
    private func formatTime(_ seconds: Int) -> String {
        let minutes = seconds / 60
        let secs = seconds % 60
        return String(format: "%02d:%02d", minutes, secs)
    }
}
