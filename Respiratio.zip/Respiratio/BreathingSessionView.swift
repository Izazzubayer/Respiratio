//
//  BreathingSessionView.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-21.
//

import SwiftUI
import CoreHaptics

struct BreathingSessionView: View {
    let exercise: BreathingExercise
    @Environment(\.presentationMode) var presentationMode
    @State private var stepIndex = 0
    @State private var circleScale: CGFloat = 0.5
    @State private var timer: Timer? = nil
    @State private var animationTimer: Timer? = nil
    @State private var isPaused = false
    @State private var remainingTime: TimeInterval = 120 // 2-minute countdown
    @State private var animationCurve: [Float] = []
    @State private var animationStep = 0
    @State private var currentPlayer: CHHapticAdvancedPatternPlayer?

    let haptics = BreathingHaptics()
    var loop: Bool = false // Set true if you want the session to loop

    var body: some View {
        VStack(spacing: 40) {
            Text(exercise.name)
                .font(.largeTitle)

            Text(exercise.pattern[stepIndex].label)
                .font(.system(size: 36, weight: .bold))

            Circle()
                .fill(Color.green.opacity(0.5))
                .frame(width: 200, height: 200)
                .scaleEffect(circleScale)

            Text("\(Int(remainingTime))s")
                .font(.title2)
                .monospacedDigit()

            HStack(spacing: 50) {
                Button(action: { togglePause() }) {
                    Image(systemName: isPaused ? "play.fill" : "pause.fill")
                        .font(.system(size: 30))
                }

                Button(action: {
                    stopSession()
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "stop.fill")
                        .font(.system(size: 30))
                }
            }
        }
        .onAppear { startSession() }
    }

    func startSession() {
        stepIndex = 0
        remainingTime = 120
        isPaused = false
        runStep()
        startCountdown()
    }

    func startCountdown() {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { t in
            guard !isPaused else { return }
            if remainingTime > 0 {
                remainingTime -= 1
            } else {
                t.invalidate()
            }
        }
    }

    func runStep() {
        guard stepIndex < exercise.pattern.count else { return }
        let step = exercise.pattern[stepIndex]
        let duration = step.duration

        animationCurve = haptics.intensityCurve(for: step.label, duration: duration)
        animationStep = 0

        // Play haptics
        do {
            var events = [CHHapticEvent]()
            let curve = animationCurve
            let steps = curve.count
            for i in 0..<steps {
                let t = Double(i) / Double(steps)
                let intensity = curve[i]
                let sharpness = intensity
                let event = CHHapticEvent(
                    eventType: .hapticContinuous,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity),
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness)
                    ],
                    relativeTime: t * duration,
                    duration: duration / Double(steps)
                )
                events.append(event)
            }
            let patternObj = try CHHapticPattern(events: events, parameters: [])
            currentPlayer = haptics.makePlayer(with: patternObj)
            try currentPlayer?.start(atTime: 0)
        } catch {
            print("Failed to play haptic pattern: \(error)")
        }

        // Animation timer
        animationTimer?.invalidate()
        animationTimer = Timer.scheduledTimer(withTimeInterval: duration / Double(animationCurve.count), repeats: true) { _ in
            guard !isPaused else { return }
            if animationStep < animationCurve.count {
                let intensity = animationCurve[animationStep]
                switch step.label.lowercased() {
                case "inhale":
                    circleScale = 0.5 + CGFloat(intensity) * 0.5
                case "exhale":
                    circleScale = 0.5 + CGFloat(intensity) * 0.5
                case "hold":
                    circleScale = 1.0
                default:
                    circleScale = 0.5 + CGFloat(intensity) * 0.5
                }
                animationStep += 1
            } else {
                animationTimer?.invalidate()
            }
        }

        // Schedule next step
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: duration, repeats: false) { _ in
            guard !isPaused else { return }
            if stepIndex + 1 < exercise.pattern.count {
                stepIndex += 1
                runStep()
            } else if loop {
                stepIndex = 0
                runStep()
            } else {
                stopSession()
            }
        }
    }

    func togglePause() {
        if isPaused {
            // Resume
            isPaused = false
            runStep()
        } else {
            // Pause immediately
            isPaused = true
            timer?.invalidate()
            animationTimer?.invalidate()
            try? currentPlayer?.stop(atTime: 0)
        }
    }

    func stopSession() {
        timer?.invalidate()
        animationTimer?.invalidate()
        try? currentPlayer?.stop(atTime: 0)
        circleScale = 0.5
        remainingTime = 120
        isPaused = false
    }
}
