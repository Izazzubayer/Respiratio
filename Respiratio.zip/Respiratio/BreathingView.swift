//
//  BreathingView.swift
//  Respiratio
//
//  Created by Izzy Drizzy on 2025-08-20.
//
import SwiftUI
import UIKit

struct BreathingView: View {
    @State private var selectedExercise: BreathingExercise? = nil
    
    var body: some View {
        NavigationView {
            List(breathingExercises) { exercise in
                VStack(alignment: .leading, spacing: 5) {
                    Text(exercise.name)
                        .font(.headline)
                    Text(exercise.description)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Text(exercise.tag)
                        .font(.caption)
                        .foregroundColor(.blue)
                        .padding(5)
                        .background(Color.blue.opacity(0.1))
                        .cornerRadius(5)
                }
                .padding(5)
                .onTapGesture {
                    selectedExercise = exercise
                }
            }
            .navigationTitle("Breathing Exercises")
            .sheet(item: $selectedExercise) { exercise in
                BreathingSessionView(exercise: exercise)
            }
        }
    }
}
